#!/bin/bash

#overwrite the given file with the header
echo "<TABLE>" > $2

#use sed to change all commas to </TD><TD>
#then use sed to add to the beginning of each line <TR><TD>
#add to the end of each line </TD></TR>
#append this all to the output file given as an argument
sed -e 's/,/<\/TD><TD>/g' -e 's/^/<TR><TD>/' -e 's/$/<\/TD><\/TR>/' $1 >> $2

#append to the end of the file the <\TABLE>
echo "</TABLE>" >> $2
