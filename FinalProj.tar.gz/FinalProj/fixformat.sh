#!/bin/bash


#check if there are exactly two arguments (2.3)
if [[ $# != 2 ]]; then
	
	#there isn't two arguments -> display error message and terminate
	echo "Usage fixformat.sh <dirname> <opfile>"

	exit 1
fi

#check if the first argument is a valid directory (2.4)
if [[ ! -d $1 ]]; then

	#directory isn't valid -> display error message and terminate
	echo "Error $1 is not a valid directory"
	
	exit 1
fi

#write to the output file the header (2.5 only writes after error/usage is checked)
echo "User Email,Name (Original Name),Lab,Total Duration (Minutes)" > $2

#(2.6)
#loop through all the files that are titled appropriately in the given directory
for i in $(find $1 -name "[Ll][Aa][Bb]-[AaBbCcDdEeFfGgHhIi].csv")
do
	#get name of the file
	FILENAME=${i##*/}
	
	#isolate lab letter
	LAB=${FILENAME:4:1}
	
	#make a global variable and make it uppercase
	export LABLETTER=${LAB^}
	

	
	#using awk we parse through the field with a comma as the delimeter starting after the header
	#if the file has 4 fields (1st type of format) display the appropriate fields along with the lab letter
	#if the file has 6 fields (2nd type of format) display the appropriate fields along with the lab letter
	#send this output to the file given in the second argument	
	tail -n +2 $i | awk '
	BEGIN {FS=",";OFS=",";VAR1=$LABLETTER}
	{ LL=ENVIRON["LABLETTER"] }
	{ if (NF ==4)
		{ print $2,$1,LL,$3 } }
	{ if (NF ==6)
		{ print $2,$1,LL,$5 } }
	' >>$2 
done


