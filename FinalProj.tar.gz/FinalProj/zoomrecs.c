#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "zoomrecs.h"

//create a function that is called for each line of a file that makes a linked list (3.6)
void addZoomRecord(struct ZoomRecord** head, char *line, int count){

	//check if at the second line of the file/first line of data
        if (count==1){
		//make a pointer
                struct ZoomRecord *current;
                current=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
                //set a variable to the delimeter (comma)
		char * delim=",";
		//set the email and name of the pointer to the correct field of data
                strcpy(current->email,strtok(line,delim));
                strcpy(current->name,strtok(NULL,delim));
		//set a char pointer equal to the letter of the lab
                char *lab=strtok(NULL,delim);
		//set a char pointer to the durartion given in the line
                char *duration=strtok(NULL,delim);
		//set all of the lab durations to 0 initially
                current->durations[0]=0;
                current->durations[1]=0;
                current->durations[2]=0;
                current->durations[3]=0;
                current->durations[4]=0;
                current->durations[5]=0;
                current->durations[6]=0;
                current->durations[7]=0;
                current->durations[8]=0;
		//check if lab of the line equals letters A-I
		//if it equals a certain letter add it to the appropriate index of the durations attribute
		if (lab[0]=='A'){
			current->durations[0]+=atoi(duration);
                }
		if (lab[0]=='B'){
			current->durations[1]+=atoi(duration);
                }
                if (lab[0]=='C'){
			current->durations[2]+=atoi(duration);
                }
                if (lab[0]=='D'){
			current->durations[3]+=atoi(duration);
		}
		if (lab[0]=='E'){
			current->durations[4]+=atoi(duration);
		}
		if (lab[0]=='F'){
			current->durations[5]+=atoi(duration);
		}
		if (lab[0]=='G'){
			current->durations[6]+=atoi(duration);
		}
		if (lab[0]=='H'){
			current->durations[7]+=atoi(duration);
		}
		if (lab[0]=='I'){
			current->durations[8]+=atoi(duration);
		}


		//set the head of the linked list to current
                (*head)=current;
        }
	//check if the count is greator than 1
	if (count >1){
		//make a pointer
		struct ZoomRecord *current;
                current=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
                //set a variable to the delimeter (comma)
		char * delim=",";
		//set the email and name of the pointer to the correct fields of data
                strcpy(current->email,strtok(line,delim));
                strcpy(current->name,strtok(NULL,delim));
		//set a char pointer equal to the letter of the lab
                char *lab=strtok(NULL,delim);
		//set a char pointer equal to the duration given in line
                char *duration=strtok(NULL,delim);
		//set all of the lab durations to 0 initially
                current->durations[0]=0;
                current->durations[1]=0;
                current->durations[2]=0;
                current->durations[3]=0;
                current->durations[4]=0;
                current->durations[5]=0;
                current->durations[6]=0;
                current->durations[7]=0;
                current->durations[8]=0;
		
		//make a pointer
                struct ZoomRecord *temp;
                temp=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
                //set the pointer to the head of the linked list
		temp=*head;
		
		//set a variable equal to 0
                int count2=0;
		
		//iterate through the linked list
                while (temp!=NULL){
			//check if current pointers email is equal to an email of a node in the linked list
			if (strcmp(temp->email,current->email)==0){
				//check if the lab letter found for the line equals a certain letter
				//if it equals, add/increment the lines duration to a certain index of the nodes durations field
				//repeat for lab letters A-I
				if (lab[0]=='A'){
                                        temp->durations[0]+=atoi(duration);
                                }
                                if (lab[0]=='B'){
                                        temp->durations[1]+=atoi(duration);
                                }
                                if (lab[0]=='C'){
                                        temp->durations[2]+=atoi(duration);
                                }
                                if (lab[0]=='D'){
                                        temp->durations[3]+=atoi(duration);
                                }
                                if (lab[0]=='E'){
                                        temp->durations[4]+=atoi(duration);
                                }
                                if (lab[0]=='F'){
                                        temp->durations[5]+=atoi(duration);
                                }
                                if (lab[0]=='G'){
                                        temp->durations[6]+=atoi(duration);
                                }
                                if (lab[0]=='H'){
                                        temp->durations[7]+=atoi(duration);
                                }
                                if (lab[0]=='I'){
                                        temp->durations[8]+=atoi(duration);
                                }
				//leave while loop
                                break;
			}
			//check if line's email comes first alphabetically compared to the head
			if (strcmp(temp->email,current->email)>0 && count2==0 ){
				//check if the lab letter found for the line equals a certain letter
                                //if it equals, add the lines duration to a certain index of the current pointer
                                //repeat for lab letters A-I
				if (lab[0]=='A'){
                                        current->durations[0]=atoi(duration);
                                }
                                if (lab[0]=='B'){
                                        current->durations[1]=atoi(duration);
                                }
                                if (lab[0]=='C'){
                                        current->durations[2]=atoi(duration);
                                }
                                if (lab[0]=='D'){
                                        current->durations[3]=atoi(duration);
                                }
                                if (lab[0]=='E'){
                                        current->durations[4]=atoi(duration);
                                }
                                if (lab[0]=='F'){
                                        current->durations[5]=atoi(duration);
                                }
                                if (lab[0]=='G'){
                                        current->durations[6]=atoi(duration);
                                }
                                if (lab[0]=='H'){
                                        current->durations[7]=atoi(duration);
                                }
                                if (lab[0]=='I'){
                                        current->durations[8]=atoi(duration);
                                }
				//make the current node equal to the head of the linked list
                                current->next=*head;
                                (*head)=current;
				//leave the while loop
                                break;
                        }

			//set two char pointers to the current email and the email of the next node in the linked list
			char *ptr1=temp->next->email;
                        char *ptr2=current->email;

			//check if the next email in a linked list isn't NULL and the current email is alphabetically after temp node but before next node 
                        if (temp->next->email!=NULL && strcmp(ptr2,temp->email)>0 && strcmp(ptr2,ptr1)<0){
				//check if the lab letter found for the line equals a certain letter
                                //if it equals, add the lines duration to a certain index of the current durations field
                                //repeat for lab letters A-I
                                if (lab[0]=='A'){
                                        current->durations[0]=atoi(duration);
                                }
                                if (lab[0]=='B'){
                                        current->durations[1]=atoi(duration);
                                }
                                if (lab[0]=='C'){
                                        current->durations[2]=atoi(duration);
                                }
                                if (lab[0]=='D'){
                                        current->durations[3]=atoi(duration);
                                }
                                if (lab[0]=='E'){
                                        current->durations[4]=atoi(duration);
                                }
                                if (lab[0]=='F'){
                                        current->durations[5]=atoi(duration);
                                }
                                if (lab[0]=='G'){
                                        current->durations[6]=atoi(duration);
                                }
                                if (lab[0]=='H'){
                                        current->durations[7]=atoi(duration);
                                }
                                if (lab[0]=='I'){
                                        current->durations[8]=atoi(duration);
                                }
				//set the next of the current node to the temp next
                                current->next=temp->next;
				//set the next of the temp node to the current node
                                temp->next=current;
				//leave the while loop
                                break;
			}
			//check if next node in the list is NULL (at the end of the list)
			if (temp->next ==NULL){
				//check if the lab letter found for the line equals a certain letter
                                //if it equals, add the lines duration to a certain index of the current nodes durations field
                                //repeat for lab letters A-I
                                if (lab[0]=='A'){
                                        current->durations[0]=atoi(duration);
                                }
                                if (lab[0]=='B'){
                                        current->durations[1]=atoi(duration);
                                }
                                if (lab[0]=='C'){
                                        current->durations[2]=atoi(duration);
                                }
                                if (lab[0]=='D'){
                                        current->durations[3]=atoi(duration);
                                }
                                if (lab[0]=='E'){
                                        current->durations[4]=atoi(duration);
                                }
                                if (lab[0]=='F'){
                                        current->durations[5]=atoi(duration);
                                }
                                if (lab[0]=='G'){
                                        current->durations[6]=atoi(duration);
                                }
                                if (lab[0]=='H'){
                                        current->durations[7]=atoi(duration);
                                }
                                if (lab[0]=='I'){
                                        current->durations[8]=atoi(duration);
                                }
				//set the last node in the linked list equal to the current
                                temp->next=current;
				//leave the while loop
                                break;
                        }
			//add to the count variable
                        count2++;
			//move to the next node
                        temp=temp->next;

                }

        }
}

//create function to be called once that will read through linked list and add to a csv file (3.7)			
void generateAttendance(struct ZoomRecord* head, FILE *output_file){
	//create a pointer
        struct ZoomRecord *temp;
        temp=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
	//add to the output file the header
        fprintf(output_file,"User Email,Name (Original Name),A,B,C,D,E,F,G,H,I,Attendance (Percentage)\n");

	//set temp to the head of the linked list
        temp=head;
	//iterate through all the nodes of the linked list
        while (temp!=NULL){
		//write to the output file the email and name
                fprintf(output_file, "%s,%s,",temp->email,temp->name);
		//make a count variable
                float count=0;
		//iterate through all the lab durations
                for (int i=0; i<9; i++){
			//only add to the count if duration is above 45
                        if (temp->durations[i]>=45){
                                count++;
                        }
			//add each duration to the output file
                        fprintf(output_file,"%d,",temp->durations[i]);
                }
		//find the percent of attendance (over 45 minutes) for the person
                float percentage=count/9*100;
		//add that percentage of attendance rounded to 2 decimal places to the output file 
                fprintf(output_file,"%.2f\n",percentage);

                //move to the next node
		temp=temp->next;

        }

}





