#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "zoomrecs.h"

//write a main function to create the alphabetically sorted csv file with lab attendance
int main(int argc, char *argv[]){
	
	//make a pointer point to the content of the input file
	FILE *input_file = fopen(argv[1], "rt");

	//set a variable equal to 0
	int count=0;

	//make a pointer called head to iterate through linked list
	struct ZoomRecord *head;
	head=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
	
	//each line can be read into a char array of 200
	char line[200];

	//iterate through the lines of an input file	
	while (fgets(line, sizeof(line), input_file)){
		
		//call function to add zoom records in to a linked list (3.6)
		addZoomRecord(&head,line,count);
		
		//add to the count variable
		count++;

		
	}
	//close the input file after using it
	fclose(input_file);

	
	//open the output file to be able to write in it
	FILE *output_file = fopen(argv[2], "w");

	//call function to add into csv file organized data (3.7)
	generateAttendance(head,output_file);

	//close the output file
	fclose(output_file);	
	
	//free all dynamic data (3.11)
	//make two pointers
	struct ZoomRecord *temp1;
        temp1=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));

        struct ZoomRecord *temp2;
        temp2=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
	
	//set the first pointer to the head of the linked list
        temp1=head;
	//iterate through each node in the linked list
        while (temp1 !=NULL){
		//set one pointer equal to a node
                temp2=temp1;
		//set another pointer equal to the next node
                temp1=temp1->next;
		//free the current node
                free(temp2);
        }
	
	//make sure all the pointers are free
	temp1=NULL;
        free(temp1);
	temp2=NULL;
        free(temp2);
	head=NULL;
        free(head);

}
