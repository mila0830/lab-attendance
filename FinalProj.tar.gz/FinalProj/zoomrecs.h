#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//create the struct for each zoom record given (3.4)
struct ZoomRecord
{
	char email[60]; // email of the student
	char name[60]; // name of the student
	int durations[9]; // duration for each lab.
	struct ZoomRecord *next;
};

//tell the compiler that the following pointer  and function will be defined else where
extern struct ZoomRecord *head;
void addZoomRecord(struct ZoomRecord** head, char *line, int count);
void generateAttendance(struct ZoomRecord* head, FILE *output_file);
